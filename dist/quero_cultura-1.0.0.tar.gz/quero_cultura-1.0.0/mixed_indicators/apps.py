from django.apps import AppConfig


class MixedIndicatorsConfig(AppConfig):
    name = 'mixed_indicators'
