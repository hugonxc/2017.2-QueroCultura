from django.apps import AppConfig


class SpaceIndicatorsConfig(AppConfig):
    name = 'space_indicators'
