from django.apps import AppConfig


class MuseumsIndicatorsConfig(AppConfig):
    name = 'museums_indicators'
