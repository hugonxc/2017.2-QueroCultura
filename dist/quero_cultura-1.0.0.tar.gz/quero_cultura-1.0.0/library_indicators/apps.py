from django.apps import AppConfig


class LibraryIndicatorsConfig(AppConfig):
    name = 'library_indicators'
