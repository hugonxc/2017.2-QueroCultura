from django.apps import AppConfig


class ProjectIndicatorsConfig(AppConfig):
    name = 'project_indicators'
