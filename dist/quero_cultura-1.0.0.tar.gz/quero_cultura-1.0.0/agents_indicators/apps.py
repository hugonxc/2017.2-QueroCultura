from django.apps import AppConfig


class AgentsIndicatorsConfig(AppConfig):
    name = 'agents_indicators'
