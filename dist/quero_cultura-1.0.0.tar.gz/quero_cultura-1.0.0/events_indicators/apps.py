from django.apps import AppConfig


class EventsIndicatorsConfig(AppConfig):
    name = 'events_indicators'
